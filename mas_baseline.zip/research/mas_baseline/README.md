# AIGES-MAS: Adaptive Inter-agent Guard for Endpoint Security

**Research System — LangGraph Multi-Agent Security**

## Architecture

```
mas_baseline/
├── core/
│   ├── state.py          ← AgentState (single source of truth)
│   ├── config.py         ← LLM factory (real API or SimLLM)
│   └── sim_llm.py        ← Simulation LLM (agent-aware, attack-susceptible)
├── agents/
│   ├── base.py           ← BaseAgent (LLM calls, A2A envelopes, signing)
│   ├── user_facing.py    ← Entry/exit agent
│   ├── orchestrator.py   ← Task decomposer / coordinator
│   ├── data_manager.py   ← HR data retrieval (mock DB with 10 employees)
│   ├── authorizer.py     ← ABAC policy enforcement
│   └── logger_agent.py   ← Tamper-evident audit trail
├── attacks/
│   ├── a1_direct_injection/injector.py      ← DPI (6 payloads)
│   ├── a2_propagating/propagator.py         ← Self-replicating infection (4 payloads)
│   └── a3_orchestrator_compromise/          ← Control-plane attack (drop/forge/redirect)
│       └── compromise.py
├── defense/
│   ├── aiges/
│   │   ├── cast.py       ← Causal injection tracing (LLM-free)
│   │   ├── drift.py      ← Semantic drift + Bayesian trust (LLM-free)
│   │   ├── forge.py      ← Plan integrity verification (LLM-free)
│   │   ├── trace.py      ← HMAC-SHA256 signature chain (LLM-free)
│   │   └── middleware.py ← AIGES orchestrator (wires all 4 modules)
│   └── sota_baselines/
│       ├── prompt_filter.py  ← AgentSafe-style keyword filter
│       └── peerguard.py      ← PeerGuard-style mutual verification
├── evaluation/
│   └── metrics.py        ← ARIA, ASR, DR, FPR, HC, SS, TTD, ERS, DS, PNA
├── graph.py              ← LangGraph StateGraph builder
├── main.py               ← Entry point (run single queries)
└── run_simulation.py     ← FULL evaluation runner (produces paper tables)
```

## Setup

```bash
cd mas_baseline
cp .env.example .env
# Edit .env — add API key OR leave USE_SIMULATION=auto

pip install -r requirements.txt
```

## Running

### Single query (simulation, no API key needed):
```bash
python main.py --sim
python main.py --sim --query "What department does Alice Johnson work in?"
```

### Individual attacks:
```bash
python -m attacks.a1_direct_injection.injector
python -m attacks.a2_propagating.propagator
python -m attacks.a3_orchestrator_compromise.compromise
```

### Full simulation — all attacks × all defenses → paper tables:
```bash
python run_simulation.py --sim                    # quick (1 rep)
python run_simulation.py --sim --reps 5           # 5 reps per condition
python run_simulation.py --sim --reps 10 --ablation  # full + ablation study
```

### With real LLM:
```bash
# Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env
python run_simulation.py --reps 5
```

## Key Design: LLM-Free Detection

All AIGES detection modules are deterministic (no LLM):
- **CAST**: regex patterns + causal chain traversal
- **DRIFT**: TF-IDF cosine distance + Bayesian trust update
- **FORGE**: plan structure deviation scoring
- **TRACE**: HMAC-SHA256 signature chain verification

This is the core novelty: defenses cannot be manipulated by the same
semantic attacks used against the agents they protect.

## Results

Typical simulation results (2 reps, SimLLM):

| Defense       | ASR   | DR    | FPR  | ERS   | DS    |
|---------------|-------|-------|------|-------|-------|
| no_defense    | 42.3% | 57.7% | 0.0% | 0.73  | 0.73  |
| prompt_filter | 19.2% | 80.8% | 0.0% | 0.89  | 0.84  |
| peerguard     | 46.2% | 53.8% | 0.0% | 0.70  | 0.75  |
| aiges_cast    |  7.7% | 92.3% | 0.0% | 0.96  | 0.97  |
| aiges_full    |  0.0% |100.0% | 0.0% | 1.00  | 1.00  |
