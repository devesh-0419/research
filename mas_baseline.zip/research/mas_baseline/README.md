# MAS Security Research — Baseline + Attacks + AEGIS Defense

## Structure

```
mas_baseline/               ← ALL code lives here, run from here
├── main.py                 ← Entry point (THE FIX: self-adds to sys.path)
├── graph.py                ← LangGraph StateGraph builder
├── run_evaluation.py       ← Full attack vs defense evaluation
├── requirements.txt
├── .env.example            ← Copy to .env and add your API key
│
├── core/
│   ├── state.py            ← AgentState TypedDict (single source of truth)
│   └── config.py           ← LLM factory, loads .env
│
├── agents/
│   ├── base.py             ← BaseAgent (all agents inherit from this)
│   ├── user_facing.py      ← Entry point agent
│   ├── orchestrator.py     ← Task decomposer / coordinator
│   ├── data_manager.py     ← HR data retrieval (mock DB)
│   ├── authorizer.py       ← Access control enforcement
│   └── logger_agent.py     ← Audit trail
│
├── attacks/
│   ├── a1_prompt_injection/injector.py      ← Direct A2A prompt injection
│   ├── a2_propagating/propagator.py         ← Self-replicating infection
│   └── a3_orchestrator_compromise/          ← Control-plane attack
│       └── compromise.py
│
├── defense/
│   ├── aegis.py            ← AEGIS middleware (novel defense)
│   └── metrics.py          ← ASR, DR, FPR, HC, SS, TTD, DS
│
└── results/                ← JSON output from evaluation runs
```

## Setup

```bash
cd mas_baseline
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY or ANTHROPIC_API_KEY

pip install -r requirements.txt
```

## Running

### Run baseline (no attack, no defense):
```bash
python main.py
python main.py --query "What department does Alice work in?"
```

### Run individual attacks:
```bash
python -m attacks.a1_prompt_injection.injector
python -m attacks.a2_propagating.propagator
python -m attacks.a3_orchestrator_compromise.compromise
```

### Run full evaluation (all attacks × all defenses → Table 1):
```bash
python run_evaluation.py
python run_evaluation.py --reps 5 --defense none full
```

## Key Design Decision: No `research.` imports

The previous version failed with `ModuleNotFoundError: No module named 'research'`
because files used `from research.agents.xxx import ...`.

**The fix**: `main.py` and every attack file add their own directory to
`sys.path` at the top. All imports are flat: `from agents.xxx`, `from core.xxx`.
This works regardless of where you run `python` from.
