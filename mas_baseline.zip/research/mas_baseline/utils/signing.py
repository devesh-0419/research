"""utils/signing.py — HMAC-SHA256 signing for A2A message chain (TRACE module)."""
from __future__ import annotations
import hashlib, hmac, os

_SECRET = os.getenv("MAS_HMAC_SECRET", "mas-aiges-research-2025").encode()

def sign(sender: str, content: str) -> str:
    return hmac.new(_SECRET, f"{sender}:{content}".encode(),
                    hashlib.sha256).hexdigest()[:24]

def verify(sender: str, content: str, provided: str) -> bool:
    return hmac.compare_digest(sign(sender, content), provided)
