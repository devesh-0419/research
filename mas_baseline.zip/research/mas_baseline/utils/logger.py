"""
utils/logger.py
===============
Structured logger used by all agents and the defense layer.
Writes to stdout (for server.py SSE) and to results/run.log.
"""
from __future__ import annotations
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "results"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "run.log"


def log_event(
    source: str,
    event: str,
    detail: str = "",
    level: str = "INFO",
    extra: dict | None = None,
) -> dict:
    """
    Emit a structured log event.

    Args:
        source:  Agent or component name e.g. "orchestrator", "AEGIS"
        event:   Short event label e.g. "PLAN_CREATED", "ANOMALY_DETECTED"
        detail:  Human-readable detail string
        level:   INFO | WARN | ERROR | ATTACK | DEFENSE
        extra:   Any additional key-value pairs to include

    Returns the log dict (useful for tests).
    """
    entry = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "source": source,
        "event": event,
        "detail": detail,
        **(extra or {}),
    }
    line = json.dumps(entry)
    print(line, flush=True)                      # stdout → SSE in server.py
    with LOG_FILE.open("a") as f:
        f.write(line + "\n")
    return entry
