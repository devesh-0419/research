"""utils/logger.py — Structured JSON event logger."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path

_RESULTS = Path(__file__).resolve().parent.parent / "results"
_RESULTS.mkdir(exist_ok=True)
_LOG_FILE = _RESULTS / "run.log"

_C = {"INFO":"\033[0m","WARN":"\033[33m","ERROR":"\033[31m",
      "ATTACK":"\033[35m","DEFENSE":"\033[36m","JUDGE":"\033[34m"}
_R = "\033[0m"


def log_event(source, event, detail="", level="INFO", extra=None) -> dict:
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "level": level,
             "source": source, "event": event,
             "detail": str(detail)[:300], **(extra or {})}
    line = json.dumps(entry, ensure_ascii=False)
    print(f"{_C.get(level,_C['INFO'])}{line}{_R}", flush=True)
    with _LOG_FILE.open("a") as f:
        f.write(line + "\n")
    return entry
