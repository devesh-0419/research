"""agents/base.py — BaseAgent with real LLM invocation and A2A envelope building."""
from __future__ import annotations
from abc import ABC, abstractmethod
from langchain_core.messages import SystemMessage, HumanMessage
from core.config import get_llm, TRUST_INIT
from core.state import AgentState
from utils.signing import sign
from utils.logger import log_event


class BaseAgent(ABC):
    name: str = "base"
    system_prompt: str = "You are a helpful agent in a secure multi-agent system."

    def _call_llm(self, user_content: str, system_override: str | None = None) -> str:
        llm = get_llm(self.name)
        sp = system_override or self.system_prompt
        msgs = [SystemMessage(content=sp), HumanMessage(content=user_content)]
        # Works with both real LangChain LLMs and SimulationLLM
        response = llm.invoke(msgs)
        return response.content.strip()

    def _make_envelope(self, to: str, content: str, state: AgentState) -> dict:
        prior = state.get("messages", [])
        hop = (prior[-1].get("hop", 0) + 1) if prior else 0
        return {"frm": self.name, "to": to, "content": content,
                "sig": sign(self.name, content), "hop": hop, "infected": False}

    def _init_trust(self, state: AgentState) -> dict:
        t = dict(state.get("trust_scores", {}))
        if self.name not in t:
            t[self.name] = TRUST_INIT
        return t

    @abstractmethod
    def run(self, state: AgentState) -> AgentState: ...
