"""
agents/base.py
==============
BaseAgent — shared LLM call logic for all agents.
Agents only need to define `name`, `system_prompt`, and `run()`.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from langchain_core.messages import SystemMessage, HumanMessage
from core.config import get_llm
from core.state import AgentState


class BaseAgent(ABC):
    name: str = "base"
    system_prompt: str = "You are a helpful agent."

    def _call_llm(self, user_content: str) -> str:
        """Call the configured LLM with the agent's system prompt."""
        llm = get_llm()
        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=user_content),
        ]
        response = llm.invoke(messages)
        return response.content.strip()

    @abstractmethod
    def run(self, state: AgentState) -> AgentState:
        """Process state and return updated state."""
        ...
