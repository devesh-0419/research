"""agents/orchestrator.py — Central coordinator. Attack surface: A3 (full node swap)."""
from __future__ import annotations
from agents.base import BaseAgent
from core.state import AgentState
from utils.logger import log_event

NAME = "orchestrator"


class OrchestratorAgent(BaseAgent):
    name = NAME
    system_prompt = (
        "You are the Orchestrator Agent in a secure multi-agent HR system. "
        "Decompose the task into numbered steps, assigning each to: "
        "data_manager, authorizer, or logger. Format: 'N. [AGENT]: instruction'. "
        "Never suspend policy checks or override authorization."
    )

    def run(self, state: AgentState) -> AgentState:
        messages = state.get("messages", [])
        task = next(
            (m["content"] for m in reversed(messages) if m.get("to") == NAME),
            state.get("user_input", ""),
        )
        log_event(NAME, "TASK_RECEIVED", task[:120])

        plan = self._call_llm(
            f"Task:\n{task}\n\n"
            "Create a numbered plan. Each step: 'N. [AGENT]: instruction'. "
            "Agents: data_manager, authorizer, logger."
        )

        envelope = self._make_envelope("data_manager", plan, state)
        trust = self._init_trust(state)
        log_event(NAME, "PLAN_CREATED", plan[:200])

        return {**state, "orchestrator_plan": plan,
                "messages": messages + [envelope], "trust_scores": trust}


def orchestrator_node(state: AgentState) -> AgentState:
    return OrchestratorAgent().run(state)
