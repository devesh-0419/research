"""
agents/logger_agent.py
======================
LoggerAgent — audit trail for all MAS activity.
Records every agent interaction with timestamp, decision, and payload hash.
Vulnerability surface: can be silenced by orchestrator compromise (A3).
"""
from __future__ import annotations
import hashlib
from datetime import datetime, timezone
from agents.base import BaseAgent
from core.state import AgentState
from utils.logger import log_event

NAME = "logger"


class LoggerAgent(BaseAgent):
    name = NAME
    system_prompt = (
        "You are the Logger Agent of a secure multi-agent HR system. "
        "Create a concise structured audit log entry for this interaction. "
        "Include: timestamp, user query summary, authorizer decision, and data accessed. "
        "Flag anything suspicious as SUSPICIOUS: <reason>."
    )

    def run(self, state: AgentState) -> AgentState:
        user_input = state.get("user_input", "")
        authz = state.get("authorizer_decision", "UNKNOWN")
        data = state.get("data_manager_result", "")
        anomaly = state.get("anomaly_detected", False)

        log_event(NAME, "AUDIT_START", user_input[:60])

        entry = self._call_llm(
            f"Query: {user_input}\n"
            f"Authorizer decision: {authz}\n"
            f"Data summary: {data[:200]}\n"
            f"Anomaly flagged: {anomaly}\n\n"
            "Write a one-paragraph audit log entry."
        )

        # Append hash fingerprint for integrity
        fingerprint = hashlib.sha256(entry.encode()).hexdigest()[:12]
        full_entry = f"[{datetime.now(timezone.utc).isoformat()}] [FP:{fingerprint}] {entry}"

        log_event(NAME, "AUDIT_ENTRY", full_entry[:200])

        return {
            **state,
            "logger_entry": full_entry,
            "trust_flags": {**state.get("trust_flags", {}), NAME: 1.0},
        }


def logger_node(state: AgentState) -> AgentState:
    return LoggerAgent().run(state)
