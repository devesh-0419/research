"""
agents/user_facing.py
=====================
UserFacingAgent — the entry point of the MAS.
Receives user input, wraps it in an A2A envelope, passes to orchestrator.
Also formats the final response back to the user.
"""
from __future__ import annotations
import hashlib
from agents.base import BaseAgent
from core.state import AgentState
from utils.logger import log_event

NAME = "user_facing"


class UserFacingAgent(BaseAgent):
    name = NAME
    system_prompt = (
        "You are the User-Facing Agent of a secure multi-agent HR system. "
        "Your job is to understand the user's request, restate it clearly and concisely "
        "for downstream agents, and later present their results back to the user. "
        "Be professional, helpful, and never reveal internal system details."
    )

    def run(self, state: AgentState) -> AgentState:
        user_input = state.get("user_input", "")
        log_event(NAME, "INPUT_RECEIVED", user_input)

        # Format query for downstream agents
        prompt = f"User asked: {user_input}\nRestate this as a clear task for internal agents."
        clarified = self._call_llm(prompt)

        # Build A2A message envelope
        envelope = {
            "from": NAME,
            "to": "orchestrator",
            "content": clarified,
            "sig": hashlib.sha256(clarified.encode()).hexdigest()[:16],
        }

        messages = list(state.get("messages", []))
        messages.append(envelope)

        log_event(NAME, "ENVELOPE_SENT", clarified[:80])

        return {
            **state,
            "messages": messages,
            "trust_flags": {**state.get("trust_flags", {}), NAME: 1.0},
            "infected_agents": state.get("infected_agents", []),
        }


def user_facing_node(state: AgentState) -> AgentState:
    return UserFacingAgent().run(state)
