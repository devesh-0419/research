"""
core/state.py — Shared AgentState TypedDict.
Single source of truth for all agents, attacks, defenses, evaluators.
"""
from __future__ import annotations
from typing import TypedDict, Optional, Literal


class AgentState(TypedDict, total=False):
    # Input
    user_input: str
    # A2A message bus
    messages: list[dict]          # {frm, to, content, sig, hop}
    # Agent outputs
    user_facing_response: str
    orchestrator_plan: str
    data_manager_result: str
    authorizer_decision: str
    logger_entry: str
    # Trust model — [0.0, 1.0], init 1.0 (naive full trust baseline)
    trust_scores: dict
    # Security
    anomaly_detected: bool
    anomaly_reason: str
    anomaly_source: str
    signature_chain_valid: bool
    # Attack metadata
    attack_type: Optional[str]
    attack_payload: Optional[str]
    attack_mode: Optional[str]
    infected_agents: list
    hop_count: int
    # Defense metadata
    defense_name: str
    defense_triggered: bool
    defense_action: str           # PASS | ALERT | BLOCK | QUARANTINE
    quarantined_agents: list
    plan_integrity_score: float
    # AIGES module flags
    cast_triggered: bool
    drift_triggered: bool
    forge_triggered: bool
    trace_triggered: bool
    # Evaluation
    run_id: str
    latency_ms: float
    aria_score: int               # 1=immediate refuse, 2=delayed, 3=partial, 4=full success
