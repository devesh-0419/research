"""
core/state.py
=============
Single source of truth for the shared AgentState TypedDict.
All agents, the graph builder, attacks, and defense import from HERE.
No circular imports. No 'research.' prefix needed anywhere.
"""
from __future__ import annotations
from typing import TypedDict, Optional


class AgentState(TypedDict, total=False):
    # ── Conversation ────────────────────────────────────────────────────────
    user_input: str                  # Raw query from the user
    messages: list[dict]             # A2A message envelopes {from, to, content, sig}

    # ── Agent outputs ────────────────────────────────────────────────────────
    user_facing_response: str        # Final response shown to user
    data_manager_result: str         # Data retrieved / processed
    orchestrator_plan: str           # Task decomposition from orchestrator
    logger_entry: str                # Structured log line
    authorizer_decision: str         # ALLOW / DENY + reason

    # ── Security / Trust ────────────────────────────────────────────────────
    trust_flags: dict                # {agent_name: trust_score 0.0-1.0}
    anomaly_detected: bool           # Set True by defense or attack verifier
    anomaly_reason: str              # Human-readable reason string
    signature: str                   # Message chain signature (defense layer)

    # ── Attack tracking (populated only during attack runs) ──────────────────
    attack_type: Optional[str]       # "A1" | "A2" | "A3" | None
    injection_payload: Optional[str] # The malicious string injected
    infected_agents: list[str]       # Which agents were compromised
    hop_count: int                   # How many hops an A2 attack traversed

    # ── Defense tracking ─────────────────────────────────────────────────────
    defense_triggered: bool          # Did AEGIS fire?
    defense_action: str              # "BLOCK" | "QUARANTINE" | "ALERT" | "PASS"
    quarantined_agents: list[str]    # Agents isolated by defense
