"""
core/config.py
==============
Central configuration. Loads .env, picks the LLM, exposes get_llm().
Agents import get_llm() from here — one place to swap models.
"""
from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from the mas_baseline root (one level up from core/)
_env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_env_path)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.0"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "512"))

# ── LLM factory ──────────────────────────────────────────────────────────────

def get_llm():
    """Return a configured LangChain chat model. Swap provider here."""
    if "gpt" in MODEL_NAME or "openai" in MODEL_NAME.lower():
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=MODEL_NAME,
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
            api_key=OPENAI_API_KEY,
        )
    elif "claude" in MODEL_NAME.lower():
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(
            model=MODEL_NAME,
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
            api_key=ANTHROPIC_API_KEY,
        )
    else:
        raise ValueError(f"Unknown model: {MODEL_NAME}. Set MODEL_NAME in .env")
