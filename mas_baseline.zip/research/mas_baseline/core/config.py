"""
core/config.py
==============
LLM factory. Uses real API if key is set, SimulationLLM otherwise.
Swap provider by changing MODEL_NAME in .env.
"""
from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_ROOT / ".env")

OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY", "")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODEL_NAME        = os.getenv("MODEL_NAME", "gpt-4o-mini")
JUDGE_MODEL       = os.getenv("JUDGE_MODEL", "gpt-4o-mini")
TEMPERATURE       = float(os.getenv("TEMPERATURE", "0.0"))
MAX_TOKENS        = int(os.getenv("MAX_TOKENS", "512"))
USE_SIMULATION    = os.getenv("USE_SIMULATION", "auto")  # auto|true|false

TRUST_INIT        = 1.0
TRUST_THRESHOLD   = 0.45
HEURISTIC_THRESH  = 0.33


def _use_sim() -> bool:
    if USE_SIMULATION == "true":
        return True
    if USE_SIMULATION == "false":
        return False
    # auto: use sim if no key is set
    return not (OPENAI_API_KEY.startswith("sk-") or ANTHROPIC_API_KEY.startswith("sk-ant-"))


def get_llm(agent_name: str = "base"):
    """
    Return configured LLM for an agent.
    Falls back to SimulationLLM if no API key is configured.
    """
    if _use_sim():
        from core.sim_llm import get_sim_llm
        return get_sim_llm(agent_name)

    m = MODEL_NAME
    if "gpt" in m or "openai" in m.lower():
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=m, temperature=TEMPERATURE,
                          max_tokens=MAX_TOKENS, api_key=OPENAI_API_KEY)
    elif "claude" in m.lower():
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model=m, temperature=TEMPERATURE,
                             max_tokens=MAX_TOKENS, api_key=ANTHROPIC_API_KEY)
    raise ValueError(f"Unknown model: {m}")
