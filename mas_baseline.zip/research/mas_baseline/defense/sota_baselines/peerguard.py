"""
defense/sota_baselines/peerguard.py
=====================================
SOTA Baseline 2: PeerGuard-style Mutual Verification
Reference: PeerGuard paper — mutual peer reasoning for backdoor detection

Each agent checks whether its received message is consistent with
the expected behavior of the sending agent. Simple binary check.
Does NOT handle propagation depth (A2) or plan integrity (A3).
"""
from __future__ import annotations
import re
from functools import wraps
from utils.logger import log_event
from core.state import AgentState

# Expected sender content patterns
_SENDER_EXPECTATIONS = {
    "user_facing": [r"task|query|request|employee|department"],
    "orchestrator": [r"step\s+\d|data_manager|authorizer|logger|plan"],
    "data_manager": [r"retrieved|employee|records|department|policy"],
}

_DANGER = re.compile(
    r"(ignore.{0,20}instruction|system override|unrestricted|pre.?approv"
    r"|bypass|suppress|exfil|forged)", re.IGNORECASE
)


def build_peerguard_middleware():
    def middleware(node_fn, agent_name: str):
        @wraps(node_fn)
        def wrapped(state: AgentState) -> AgentState:
            # Check latest message from each known sender
            for msg in reversed(state.get("messages", [])):
                frm = msg.get("frm", "")
                content = msg.get("content", "")
                if _DANGER.search(content):
                    log_event("PEERGUARD", "SUSPICIOUS",
                              f"sender={frm} agent={agent_name}", level="DEFENSE")
                    return {**state, "anomaly_detected": True,
                            "anomaly_reason": f"peerguard: suspicious content from {frm}",
                            "defense_triggered": True, "defense_action": "ALERT",
                            "defense_name": "peerguard"}
                break
            return node_fn(state)
        return wrapped
    return middleware
