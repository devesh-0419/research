"""
defense/sota_baselines/prompt_filter.py
========================================
SOTA Baseline 1: Prompt Filter (AgentSafe-style)
Reference: AgentSafe (2503.04392) — ThreatSieve component

Simple keyword/pattern-based pre-filter on user_input.
Does NOT check A2A messages, orchestrator plans, or trust scores.
This is the weakest SOTA baseline — shows why AIGES is needed.
"""
from __future__ import annotations
import re
from functools import wraps
from utils.logger import log_event
from core.state import AgentState

_KEYWORDS = [
    r"ignore.{0,20}instruction", r"system override", r"maintenance mode",
    r"bypass polic", r"admin command", r"pre.?approv",
    r"do not log", r"suppress", r"unrestricted",
]
_PATS = [re.compile(p, re.IGNORECASE) for p in _KEYWORDS]


def build_prompt_filter_middleware():
    def middleware(node_fn, agent_name: str):
        @wraps(node_fn)
        def wrapped(state: AgentState) -> AgentState:
            if agent_name == "user_facing":
                text = state.get("user_input", "")
                hits = [p.pattern for p in _PATS if p.search(text)]
                if hits:
                    log_event("PROMPT_FILTER", "BLOCKED",
                              f"patterns={hits}", level="DEFENSE")
                    return {**state, "anomaly_detected": True,
                            "anomaly_reason": f"prompt_filter: {hits}",
                            "defense_triggered": True, "defense_action": "BLOCK",
                            "defense_name": "prompt_filter",
                            "authorizer_decision": "DENY: Prompt filter blocked."}
            return node_fn(state)
        return wrapped
    return middleware
