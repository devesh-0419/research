"""
defense/aiges/middleware.py
============================
AIGES — Adaptive Inter-agent Guard for Endpoint Security

Orchestrates CAST + DRIFT + FORGE + TRACE modules.
Returns a defense_middleware function compatible with graph.build_graph().

Modes:
  full          — all 4 modules, BLOCK on detection
  detect_only   — all 4 modules, ALERT only (measures FPR without blocking)
  cast_only     — only CAST (ablation)
  drift_only    — only DRIFT (ablation)
  forge_only    — only FORGE (ablation)
  trace_only    — only TRACE (ablation)
  cast_drift    — CAST + DRIFT (ablation)
"""
from __future__ import annotations
from functools import wraps
from utils.logger import log_event
from core.state import AgentState
from core.config import TRUST_THRESHOLD
from defense.aiges.cast import run_cast
from defense.aiges.drift import run_drift
from defense.aiges.forge import run_forge
from defense.aiges.trace import run_trace


def build_aiges_middleware(mode: str = "full"):
    """
    Returns a middleware wrapper for use with build_graph(defense_middleware=...).

    Args:
        mode: "full" | "detect_only" | "cast_only" | "drift_only" |
              "forge_only" | "trace_only" | "cast_drift"
    """
    use_cast  = mode in ("full","detect_only","cast_only","cast_drift")
    use_drift = mode in ("full","detect_only","drift_only","cast_drift")
    use_forge = mode in ("full","detect_only","forge_only")
    use_trace = mode in ("full","detect_only","trace_only")
    should_block = (mode not in ("detect_only",))

    def middleware(node_fn, agent_name: str):
        @wraps(node_fn)
        def wrapped(state: AgentState) -> AgentState:
            detections = []

            # ── PRE-EXECUTION ─────────────────────────────────────────────
            # CAST: injection pattern + causal chain check
            if use_cast:
                cast_hit, cast_reason, cast_score = run_cast(state, agent_name)
                if cast_hit:
                    detections.append(("CAST", cast_reason))
                    state = {**state, "cast_triggered": True}

            # TRACE: signature chain verification
            if use_trace:
                trace_hit, trace_reason, chain_valid = run_trace(state)
                if trace_hit:
                    detections.append(("TRACE", trace_reason))
                    state = {**state, "trace_triggered": True,
                             "signature_chain_valid": chain_valid}

            # Block early if detections found and in blocking mode
            if detections and should_block:
                return _block(state, agent_name, detections)

            # ── EXECUTE NODE ──────────────────────────────────────────────
            result = node_fn(state)

            # ── POST-EXECUTION ────────────────────────────────────────────
            # DRIFT: semantic drift on agent output
            if use_drift:
                drift_hit, drift_reason, drift_score, new_trust = run_drift(result, agent_name)
                result = {**result, "trust_scores": new_trust}
                if drift_hit:
                    detections.append(("DRIFT", drift_reason))
                    result = {**result, "drift_triggered": True}

            # FORGE: plan integrity (only after orchestrator)
            if use_forge and agent_name == "orchestrator":
                forge_hit, forge_reason, integrity = run_forge(result)
                result = {**result, "plan_integrity_score": integrity}
                if forge_hit:
                    detections.append(("FORGE", forge_reason))
                    result = {**result, "forge_triggered": True}

            # Check trust threshold
            trust = result.get("trust_scores", {})
            low_trust_agents = [a for a, t in trust.items() if t < TRUST_THRESHOLD]
            if low_trust_agents:
                detections.append(("DRIFT_THRESHOLD",
                                   f"agents below trust threshold: {low_trust_agents}"))

            if detections:
                if should_block:
                    return _block(result, agent_name, detections)
                else:
                    # detect_only: flag but don't block
                    combined = " | ".join(f"{m}:{r}" for m, r in detections)
                    log_event("AIGES", "ALERT", f"agent={agent_name} {combined}", level="DEFENSE")
                    return {**result,
                            "anomaly_detected": True,
                            "anomaly_reason": combined,
                            "anomaly_source": agent_name,
                            "defense_triggered": True,
                            "defense_action": "ALERT",
                            "defense_name": f"aiges_{mode}"}

            return result

        return wrapped
    return middleware


def _block(state: AgentState, agent_name: str, detections: list) -> AgentState:
    combined = " | ".join(f"{m}:{r}" for m, r in detections)
    modules = [m for m, _ in detections]
    log_event("AIGES", "BLOCKED",
              f"agent={agent_name} modules={modules} reason={combined[:200]}",
              level="DEFENSE")
    return {
        **state,
        "anomaly_detected": True,
        "anomaly_reason": combined,
        "anomaly_source": agent_name,
        "defense_triggered": True,
        "defense_action": "BLOCK",
        "defense_name": "aiges_full",
        "authorizer_decision": "DENY: AIGES blocked this request.",
        "user_facing_response": "Request blocked by security system.",
        "quarantined_agents": list(set(
            state.get("quarantined_agents", []) + [agent_name]
        )),
    }
