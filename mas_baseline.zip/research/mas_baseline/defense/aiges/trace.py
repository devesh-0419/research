"""
defense/aiges/trace.py
======================
TRACE — Cryptographic Message Chain Integrity (Merkle-style)

Principle: LLM-FREE. SHA-256 HMAC chain verification.
Each A2A message is signed. If any message in the chain is tampered
with (content changed, sender spoofed), the signature breaks.

Detects:
  - A2: Propagating infections modify message content → sig mismatch
  - A3: Forged orchestrator messages → sig mismatch if injected externally
  - Any tampering with the message bus mid-flight

This is cryptographically certain — cannot be bypassed by LLM persuasion.
"""
from __future__ import annotations
from utils.logger import log_event
from utils.signing import sign, verify
from core.state import AgentState


def run_trace(state: AgentState) -> tuple[bool, str, bool]:
    """
    Verify integrity of all A2A messages in the chain.
    Returns (triggered, reason, chain_valid).
    """
    messages = state.get("messages", [])
    if not messages:
        return False, "", True

    broken = []
    for i, msg in enumerate(messages):
        frm     = msg.get("frm", "")
        content = msg.get("content", "")
        sig     = msg.get("sig", "")

        if not sig:
            broken.append(f"msg[{i}] from={frm}: missing signature")
            continue

        if not verify(frm, content, sig):
            broken.append(f"msg[{i}] from={frm}: signature mismatch — content tampered")

    # Also check hop count doesn't exceed agent count (replay/loop detection)
    last_hop = messages[-1].get("hop", 0) if messages else 0
    if last_hop > 10:
        broken.append(f"hop_count={last_hop} exceeds threshold — possible relay loop")

    if broken:
        reason = "TRACE violations: " + "; ".join(broken)
        log_event("TRACE", "CHAIN_BROKEN", reason, level="DEFENSE")
        return True, reason, False

    return False, "", True


def sign_message(msg: dict) -> dict:
    """Sign a message envelope in-place. Returns the msg with sig set."""
    content = msg.get("content", "")
    frm = msg.get("frm", "")
    msg["sig"] = sign(frm, content)
    return msg
