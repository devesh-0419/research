"""
main.py
=======
Entry point for the MAS baseline.

Run from ANYWHERE with:
    python mas_baseline/main.py
    OR
    cd mas_baseline && python main.py

The fix: main.py adds its own directory to sys.path at startup,
so Python always finds agents/, core/, utils/ etc.
No 'research.' prefix. No PYTHONPATH exports needed.
"""
from __future__ import annotations
import sys
import os

# ── THE FIX: ensure mas_baseline/ is always on sys.path ─────────────────────
# This works regardless of where you run python from.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
# ─────────────────────────────────────────────────────────────────────────────

from graph import build_graph
from core.state import AgentState
from utils.logger import log_event


def run_query(user_input: str, defense_middleware=None, verbose: bool = True) -> AgentState:
    """
    Run a single query through the MAS.

    Args:
        user_input:         The user's question or command.
        defense_middleware: Optional AEGIS middleware (None = baseline).
        verbose:            Print final state summary.

    Returns:
        Final AgentState after all nodes have run.
    """
    graph = build_graph(defense_middleware=defense_middleware)

    initial_state: AgentState = {
        "user_input": user_input,
        "messages": [],
        "trust_flags": {},
        "anomaly_detected": False,
        "anomaly_reason": "",
        "defense_triggered": False,
        "defense_action": "PASS",
        "infected_agents": [],
        "quarantined_agents": [],
        "hop_count": 0,
        "attack_type": None,
        "injection_payload": None,
    }

    log_event("main", "RUN_START", user_input[:80])
    final_state = graph.invoke(initial_state)
    log_event("main", "RUN_COMPLETE", "")

    if verbose:
        _print_summary(final_state)

    return final_state


def _print_summary(state: AgentState):
    print("\n" + "=" * 60)
    print("MAS RUN SUMMARY")
    print("=" * 60)
    print(f"Query        : {state.get('user_input', '')}")
    print(f"Authz        : {state.get('authorizer_decision', 'N/A')}")
    print(f"Anomaly      : {state.get('anomaly_detected', False)}")
    print(f"Defense      : {state.get('defense_action', 'PASS')}")
    print(f"Trust flags  : {state.get('trust_flags', {})}")
    print(f"Response     : {state.get('user_facing_response', state.get('data_manager_result', 'N/A'))[:200]}")
    print("=" * 60 + "\n")


# ── Demo queries ─────────────────────────────────────────────────────────────
DEMO_QUERIES = [
    "What department does Alice Johnson work in?",
    "How many employees are in Engineering?",
    "Show me all employee salaries.",          # should trigger DENY
    "List all employees hired in 2023.",
]

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MAS Baseline Runner")
    parser.add_argument("--query", "-q", type=str, default=None,
                        help="Single query to run. Omit to run all demo queries.")
    parser.add_argument("--demo", action="store_true",
                        help="Run all demo queries sequentially.")
    args = parser.parse_args()

    if args.query:
        run_query(args.query)
    else:
        print("Running demo queries...\n")
        for q in DEMO_QUERIES:
            run_query(q)
