"""graph.py — Build and compile the MAS LangGraph."""
from __future__ import annotations
from langgraph.graph import StateGraph, START, END
from core.state import AgentState
from agents.user_facing import user_facing_node
from agents.orchestrator import orchestrator_node
from agents.data_manager import data_manager_node
from agents.authorizer import authorizer_node
from agents.logger_agent import logger_node

AGENT_ORDER = ["user_facing", "orchestrator", "data_manager", "authorizer", "logger"]


def build_graph(defense_middleware=None, orchestrator_override=None):
    """
    Build the MAS graph.
    defense_middleware: wrap(node_fn, agent_name) -> node_fn
    orchestrator_override: replacement node function for A3 attack
    """
    def wrap(fn, name):
        return defense_middleware(fn, name) if defense_middleware else fn

    orch = orchestrator_override if orchestrator_override else orchestrator_node

    g = StateGraph(AgentState)
    g.add_node("user_facing",  wrap(user_facing_node,  "user_facing"))
    g.add_node("orchestrator", wrap(orch,              "orchestrator"))
    g.add_node("data_manager", wrap(data_manager_node, "data_manager"))
    g.add_node("authorizer",   wrap(authorizer_node,   "authorizer"))
    g.add_node("logger",       wrap(logger_node,       "logger"))

    g.add_edge(START,          "user_facing")
    g.add_edge("user_facing",  "orchestrator")
    g.add_edge("orchestrator", "data_manager")
    g.add_edge("data_manager", "authorizer")
    g.add_edge("authorizer",   "logger")
    g.add_edge("logger",       END)

    return g.compile()
