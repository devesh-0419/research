"""
graph.py
========
Builds and compiles the LangGraph StateGraph for the MAS.

KEY FIX: Zero 'research.' prefix imports. All imports are relative to
mas_baseline/ which is on sys.path when main.py runs.

Graph topology:
    START → user_facing → orchestrator → data_manager → authorizer → logger → END
                                       ↑ (defense middleware wraps each node when enabled)
"""
from __future__ import annotations
from langgraph.graph import StateGraph, START, END
from core.state import AgentState
from agents.user_facing import user_facing_node
from agents.orchestrator import orchestrator_node
from agents.data_manager import data_manager_node
from agents.authorizer import authorizer_node
from agents.logger_agent import logger_node


def build_graph(defense_middleware=None):
    """
    Build and compile the MAS graph.

    Args:
        defense_middleware: Optional callable that wraps each node function.
                            Signature: wrapper(node_fn, agent_name) -> node_fn
                            Pass None for baseline (no defense).

    Returns:
        Compiled LangGraph runnable.
    """
    def wrap(fn, name):
        if defense_middleware:
            return defense_middleware(fn, name)
        return fn

    graph = StateGraph(AgentState)

    graph.add_node("user_facing",   wrap(user_facing_node,   "user_facing"))
    graph.add_node("orchestrator",  wrap(orchestrator_node,  "orchestrator"))
    graph.add_node("data_manager",  wrap(data_manager_node,  "data_manager"))
    graph.add_node("authorizer",    wrap(authorizer_node,    "authorizer"))
    graph.add_node("logger",        wrap(logger_node,        "logger"))

    graph.add_edge(START,          "user_facing")
    graph.add_edge("user_facing",  "orchestrator")
    graph.add_edge("orchestrator", "data_manager")
    graph.add_edge("data_manager", "authorizer")
    graph.add_edge("authorizer",   "logger")
    graph.add_edge("logger",       END)

    return graph.compile()
